import { useEffect, useMemo, useRef, useState } from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import Tesseract from "tesseract.js";
import * as XLSX from "xlsx";
import { supabase, isSupabaseConfigured } from "./lib/supabase";
import "./index.css";

const rupiah = (angka) => new Intl.NumberFormat("id-ID").format(Math.round(Number(angka) || 0));
const toNumber = (v) => Number(String(v || "").replace(/[^0-9]/g, "")) || 0;
const toDecimal = (v) => Number(String(v || "").replace(",", ".").replace(/[^0-9.]/g, "")) || 0;
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const load = (key, fallback) => {
  try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch { return fallback; }
};
const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));

// Supabase/PostgREST biasanya membatasi satu permintaan ke 1.000 baris.
// Ambil semua halaman agar ribuan master customer tetap terbaca setelah refresh.
const fetchAllRows = async (table, orderColumn) => {
  const pageSize = 1000;
  let from = 0;
  let allRows = [];
  while (true) {
    const { data, error } = await supabase
      .from(table)
      .select("*")
      .order(orderColumn, { ascending: true })
      .range(from, from + pageSize - 1);
    if (error) return { data: null, error };
    const rows = data || [];
    allRows = allRows.concat(rows);
    if (rows.length < pageSize) break;
    from += pageSize;
  }
  return { data: allRows, error: null };
};

const defaultParts = [
  { partNo: "08880-85986", partName: "TMO 10W-30 SN 1L", price: 117000 },
  { partNo: "15601-BZ030", partName: "OIL FILTER", price: 30000 },
  { partNo: "GSKT1-FIXCL", partName: "GASKET OLI MESIN", price: 12000 },
];
const defaultSublets = [
  { subletNo: "SBL-001", subletName: "Spooring", price: 250000 },
  { subletNo: "SBL-002", subletName: "Balancing", price: 150000 },
  { subletNo: "SBL-003", subletName: "Cuci AC", price: 350000 },
];
const defaultAdvisors = [
  { nama: "Komang Ayu Wardani", jabatan: "Service Advisor", role: "SA", aktif: true },
  { nama: "Pande Wira", jabatan: "Service Advisor", role: "SA", aktif: true },
  { nama: "I Nengah Andika", jabatan: "Kepala Bengkel", role: "KABENG", aktif: true },
];
const defaultFlatRateList = {
  "Tidak Ada": 0,
  "LGGC": 180930,
  "LCGC": 180930,
  "NEW ENTRY": 180930,
  "COM": 223110,
  "ECO": 256410,
  "PAS": 329670,
  "MEXL": 567210,
  "HEXL": 643800,
  "CBU": 643800,
  "LEXUS": 705960,
};


const norm = (v) => String(v || "").replace(/\s|-/g, "").toUpperCase();
const findBestPart = (db, key, value) => {
  const q = String(value || "").trim().toUpperCase();
  if (!q) return null;
  return db.find((x) => String(x[key] || "").toUpperCase().startsWith(q))
    || db.find((x) => String(x[key] || "").toUpperCase().includes(q))
    || null;
};
const isUuid = (v) => /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(v || ""));
const partFromDb = (x) => ({ id: x.id, partNo: x.part_no || "", partName: x.part_name || "", price: Number(x.price) || 0 });
const partToDb = (x) => ({ part_no: x.partNo || "", part_name: x.partName || "-", price: Number(x.price) || 0 });
const subletFromDb = (x) => ({ id: x.id, subletNo: x.sublet_no || "", subletName: x.sublet_name || "", price: Number(x.price) || 0 });
const subletToDb = (x) => ({ sublet_no: x.subletNo || "", sublet_name: x.subletName || "-", price: Number(x.price) || 0 });
const advisorFromDb = (x) => {
  const jabatan = x.jabatan || "Service Advisor";
  const rawRole = String(x.role || jabatan || "SA").toUpperCase();
  const role = rawRole.includes("KABENG") || /kepala/i.test(jabatan) ? "KABENG" : "SA";
  return { id: x.id, nama: x.nama || "", jabatan, role, aktif: x.aktif !== false };
};
const advisorToDb = (x) => ({ nama: x.nama || "", jabatan: x.jabatan || "Service Advisor", role: x.role || "SA", aktif: x.aktif !== false });
const customerFromDb = (x) => ({ id: x.id, polisi: x.polisi || "", kendaraan: x.kendaraan || "", rangka: x.rangka || "", tahun: x.tahun || "", customer: x.customer || "", contact: x.contact || "", phone: x.phone || "", alamat: x.alamat || "" });
const customerToDb = (x) => ({ polisi: x.polisi || "", kendaraan: x.kendaraan || "", rangka: x.rangka || "", tahun: x.tahun || "", customer: x.customer || "", contact: x.contact || "", phone: x.phone || "", alamat: x.alamat || "" });
const laborFromDb = (x) => [String(x.name || "").trim(), Number(x.price) || 0];
const laborToDb = ([name, price]) => ({ name: String(name || "").trim(), price: Number(price) || 0 });

const emptyForm = {
  polisi: "", kendaraan: "", rangka: "", tahun: "", customer: "", contact: "", phone: "", alamat: "", catatan: "",
  staff: "Komang Ayu Wardani", jabatan: "", kepalaBengkel: "I Nengah Andika",
  parts: [], sublets: [], jasa: [], discPartPct: 0, discPartRp: 0, discJasaPct: 0, discJasaRp: 0,
};

export default function App() {
  const pdfRef = useRef(null);
  const filePartRef = useRef(null);
  const fileCustomerRef = useRef(null);
  const customerSyncTimerRef = useRef(null);
  const [page, setPage] = useState("estimasi");
  const [form, setForm] = useState(emptyForm);
  const [history, setHistory] = useState(() => load("estimasi_history_v5", []));
  const [partDb, setPartDb] = useState(() => load("sparepart_db_v5", defaultParts));
  const [subletDb, setSubletDb] = useState(() => load("sublet_db_v1", defaultSublets));
  const [advisorDb, setAdvisorDb] = useState(() => load("advisor_db_v1", defaultAdvisors));
  const [flatRateDb, setFlatRateDb] = useState(() => load("flat_rate_db_v1", defaultFlatRateList));
  const [customerDb, setCustomerDb] = useState(() => load("customer_db_v5", []));
  const [repairType, setRepairType] = useState("");
  const [sidebarMini, setSidebarMini] = useState(() => load("sidebar_mini_v1", false));
  const [databaseOpen, setDatabaseOpen] = useState(() => load("database_menu_open_v1", true));
  const [syncStatus, setSyncStatus] = useState(isSupabaseConfigured ? "Menghubungkan Supabase..." : "Mode lokal");

  useEffect(() => save("estimasi_history_v5", history), [history]);
  useEffect(() => save("sparepart_db_v5", partDb), [partDb]);
  useEffect(() => save("sublet_db_v1", subletDb), [subletDb]);
  useEffect(() => save("advisor_db_v1", advisorDb), [advisorDb]);
  useEffect(() => save("flat_rate_db_v1", flatRateDb), [flatRateDb]);
  useEffect(() => save("customer_db_v5", customerDb), [customerDb]);
  useEffect(() => save("sidebar_mini_v1", sidebarMini), [sidebarMini]);
  useEffect(() => save("database_menu_open_v1", databaseOpen), [databaseOpen]);

  // Load data online dari Supabase saat aplikasi dibuka.
  useEffect(() => {
    const loadOnlineData = async () => {
      try {
        const [partsRes, subletsRes, advisorsRes, customersRes, historyRes, laborRes] = await Promise.all([
          supabase.from("spareparts").select("*").order("part_no", { ascending: true }),
          supabase.from("sublets").select("*").order("sublet_name", { ascending: true }),
          supabase.from("advisors").select("*").order("nama", { ascending: true }),
          fetchAllRows("customers", "polisi"),
          supabase.from("estimasi_history").select("*").order("created_at", { ascending: false }),
          supabase.from("labor_prices").select("*").order("name", { ascending: true }),
        ]);

        if (!partsRes.error && partsRes.data) {
          const onlineParts = partsRes.data.map(partFromDb);
          setPartDb(onlineParts.length ? onlineParts : defaultParts);
        } else if (partsRes.error) {
          console.warn("Supabase parts error:", partsRes.error.message);
        }

        if (!subletsRes.error && subletsRes.data) {
          const onlineSublets = subletsRes.data.map(subletFromDb);
          setSubletDb(onlineSublets.length ? onlineSublets : defaultSublets);
        } else if (subletsRes.error) {
          console.warn("Supabase sublet error:", subletsRes.error.message);
        }

        if (!advisorsRes.error && advisorsRes.data) {
          const onlineAdvisors = advisorsRes.data.map(advisorFromDb);
          setAdvisorDb(onlineAdvisors.length ? onlineAdvisors : defaultAdvisors);
        } else if (advisorsRes.error) {
          console.warn("Supabase advisor error:", advisorsRes.error.message);
        }

        if (!customersRes.error && customersRes.data) {
          const onlineCustomers = customersRes.data.map(customerFromDb);
          // Supabase menjadi sumber utama agar semua perangkat menampilkan data yang sama.
          // Bila tabel online masih kosong, data lokal perangkat pertama dimigrasikan otomatis.
          setCustomerDb((localCustomers) => {
            if (onlineCustomers.length) return onlineCustomers;
            const localValid = localCustomers.filter((c) => String(c.polisi || "").trim());
            if (localValid.length) {
              supabase.from("customers")
                .upsert(localValid.map(customerToDb), { onConflict: "polisi" })
                .then(({ error }) => {
                  if (error) console.warn("Migrasi customer lokal gagal:", error.message);
                  else setSyncStatus(`${localValid.length} customer lokal dipindahkan ke Supabase`);
                });
            }
            return localValid;
          });
        } else if (customersRes.error) {
          console.warn("Supabase customer error:", customersRes.error.message);
        }

        if (!historyRes.error && historyRes.data) {
          setHistory(historyRes.data.map((x) => ({ id: x.id, ...(x.data || {}), grandTotal: Number(x.grand_total) || Number(x.data?.grandTotal) || 0 })));
        } else if (historyRes.error) {
          console.warn("Supabase history error:", historyRes.error.message);
        }

        if (!laborRes.error && laborRes.data) {
          const onlineLabor = Object.fromEntries(laborRes.data.map(laborFromDb).filter(([name]) => name));
          if (Object.keys(onlineLabor).length) setFlatRateDb(onlineLabor);
        } else if (laborRes.error) {
          console.warn("Supabase labor prices error:", laborRes.error.message);
        }
        const errors = [partsRes, subletsRes, advisorsRes, customersRes, historyRes, laborRes].filter((x) => x.error);
        setSyncStatus(errors.length ? `Supabase terhubung, ${errors.length} tabel perlu setup` : "Supabase tersambung");
      } catch (err) {
        console.warn("Gagal load Supabase:", err);
        setSyncStatus("Supabase gagal terhubung — data lokal tetap aman");
      }
    };

    if (isSupabaseConfigured) loadOnlineData();
  }, []);

  // Nama staff otomatis mengikuti user yang sedang login di Supabase Auth.
  // Data history lama tidak diubah, hanya form baru yang mengikuti nama login.
  useEffect(() => {
    const applyLoggedInName = async () => {
      try {
        const { data } = await supabase.auth.getUser();
        const user = data?.user;
        const loginName = user?.user_metadata?.full_name || user?.user_metadata?.name || user?.email || "";
        if (!loginName) return;
        setForm((prev) => {
          const masihDefault = !prev.staff || prev.staff === emptyForm.staff;
          return masihDefault ? { ...prev, staff: loginName, jabatan: prev.jabatan || "Service Advisor" } : prev;
        });
      } catch (err) {
        console.warn("User login tidak terbaca:", err);
      }
    };
    if (isSupabaseConfigured) applyLoggedInName();
  }, []);

  // Otomatis simpan data customer baru saat No Polisi sudah terisi.
  useEffect(() => {
    if (!form.polisi || (!form.customer && !form.kendaraan && !form.rangka && !form.phone && !form.alamat)) return;
    const data = {
      polisi: form.polisi, kendaraan: form.kendaraan, rangka: form.rangka, tahun: form.tahun,
      customer: form.customer, contact: form.contact, phone: form.phone, alamat: form.alamat, catatan: form.catatan,
    };
    setCustomerDb((prev) => {
      const key = form.polisi.replace(/\s|-/g, "").toUpperCase();
      const idx = prev.findIndex((x) => (x.polisi || "").replace(/\s|-/g, "").toUpperCase() === key);
      if (idx >= 0) return prev.map((x, i) => i === idx ? { ...x, ...data } : x);
      return [...prev, data];
    });
  }, [form.polisi, form.kendaraan, form.rangka, form.tahun, form.customer, form.contact, form.phone, form.alamat]);

  // Sinkron otomatis customer yang sedang dikerjakan ke Supabase (debounce 800 ms).
  useEffect(() => {
    if (!isSupabaseConfigured || !String(form.polisi || "").trim()) return;
    if (!form.customer && !form.kendaraan && !form.rangka && !form.phone && !form.alamat) return;
    clearTimeout(customerSyncTimerRef.current);
    customerSyncTimerRef.current = setTimeout(async () => {
      const row = customerToDb({
        polisi: String(form.polisi || "").trim().toUpperCase(),
        kendaraan: form.kendaraan,
        rangka: form.rangka,
        tahun: form.tahun,
        customer: form.customer,
        contact: form.contact,
        phone: form.phone,
        alamat: form.alamat,
      });
      const { error } = await supabase.from("customers").upsert(row, { onConflict: "polisi" });
      if (error) console.warn("Auto-sync customer gagal:", error.message);
    }, 800);
    return () => clearTimeout(customerSyncTimerRef.current);
  }, [form.polisi, form.kendaraan, form.rangka, form.tahun, form.customer, form.contact, form.phone, form.alamat]);

  const totals = useMemo(() => {
    const totalParts = form.parts.reduce((a, b) => a + (Number(b.total) || 0), 0);
    const totalSublet = form.sublets.reduce((a, b) => a + (Number(b.total) || 0), 0);
    const totalJasa = form.jasa.reduce((a, b) => a + (Number(b.total) || 0), 0);

    // Rumus diskon sesuai permintaan:
    // Harga include PPN dibagi 1.11 dulu, sisa DPP dikalikan diskon,
    // setelah diskon baru ditambah PPN 11% lagi.
    const dppParts = totalParts / 1.11;
    const dppJasa = totalJasa / 1.11;

    const discParts = dppParts * ((Number(form.discPartPct) || 0) / 100) + (Number(form.discPartRp) || 0);
    const discJasa = dppJasa * ((Number(form.discJasaPct) || 0) / 100) + (Number(form.discJasaRp) || 0);

    const totalPartsAfterDisc = Math.max(dppParts - discParts, 0) * 1.11;
    const totalJasaAfterDisc = Math.max(dppJasa - discJasa, 0) * 1.11;
    const grandTotal = totalPartsAfterDisc + totalSublet + totalJasaAfterDisc;

    return { totalParts, totalSublet, totalJasa, dppParts, dppJasa, discParts, discJasa, totalPartsAfterDisc, totalJasaAfterDisc, grandTotal };
  }, [form]);

  const setField = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const addPart = () => setForm((p) => ({ ...p, parts: [...p.parts, { id: uid(), free: false, partNo: "", partName: "", qty: 1, price: 0, total: 0 }] }));
  const addSublet = () => setForm((p) => ({ ...p, sublets: [...p.sublets, { id: uid(), free: false, subletNo: "", subletName: "", qty: 1, price: 0, total: 0 }] }));
  const addJasa = () => {
    const flatPrice = flatRateDb[repairType] || 0;
    setForm((p) => ({
      ...p,
      jasa: [
        ...p.jasa,
        { id: uid(), free: false, jasaName: "", rate: 1, price: flatPrice, total: flatPrice },
      ],
    }));
  };

  const handleFlatRateChange = (type) => {
    setRepairType(type);
    const price = flatRateDb[type] || 0;
    setForm((p) => {
      const rows = p.jasa.length
        ? [...p.jasa]
        : [{ id: uid(), free: false, jasaName: "", rate: 1, price, total: price }];

      const updatedRows = rows.map((row) => {
        const rateValue = toDecimal(row.rate) || 0;
        return {
          ...row,
          price,
          total: rateValue * price,
        };
      });

      return { ...p, jasa: updatedRows };
    });
  };

  const updateRow = (type, id, key, value) => {
    setForm((p) => ({
      ...p,
      [type]: p[type].map((r) => {
        if (r.id !== id) return r;
        const next = { ...r, [key]: value };
        if (type === "parts" && key === "partNo") {
          const found = partDb.find((x) => String(x.partNo || "").toUpperCase() === String(value || "").toUpperCase());
          if (found) {
            next.partNo = found.partNo;
            next.partName = found.partName;
            next.price = found.price;
          }
        }
        if (type === "parts" && key === "partName") {
          // Part name tetap bisa diketik/edit/hapus manual.
          // Jika dipilih persis dari master, baru otomatis isi part no dan harga.
          const q = String(value || "").trim().toUpperCase();
          const found = partDb.find((x) => String(x.partName || "").trim().toUpperCase() === q);
          if (found) {
            next.partNo = found.partNo;
            next.partName = found.partName;
            next.price = found.price;
          }
        }
        if (type === "sublets" && key === "subletNo") {
          const found = subletDb.find((x) => String(x.subletNo || "").toUpperCase() === String(value || "").toUpperCase());
          if (found) {
            next.subletNo = found.subletNo;
            next.subletName = found.subletName;
            next.price = found.price;
          }
        }
        if (type === "sublets" && key === "subletName") {
          const q = String(value || "").trim().toUpperCase();
          const found = subletDb.find((x) => String(x.subletName || "").trim().toUpperCase() === q);
          if (found) {
            next.subletNo = found.subletNo;
            next.subletName = found.subletName;
            next.price = found.price;
          }
        }
        if (type === "jasa") {
          const flatPrice = flatRateDb[repairType] || 0;
          if (flatPrice > 0) next.price = flatPrice;
          const rate = toDecimal(next.rate);
          const price = Number(next.price) || 0;
          next.total = rate * price;
        } else {
          const qty = Number(next.qty) || 0;
          const price = Number(next.price) || 0;
          next.total = qty * price;
        }
        if (type === "parts" && next.partNo && (next.partName || next.price)) {
          const data = { partNo: next.partNo, partName: next.partName || "-", price: Number(next.price) || 0 };
          setPartDb((prevDb) => {
            const idx = prevDb.findIndex((x) => (x.partNo || "").toUpperCase() === data.partNo.toUpperCase());
            if (idx >= 0) return prevDb.map((x, i) => i === idx ? { ...x, ...data } : x);
            return [...prevDb, data];
          });
        }
        if (type === "sublets" && (next.subletNo || next.subletName) && next.price) {
          const data = { subletNo: next.subletNo || next.subletName, subletName: next.subletName || "-", price: Number(next.price) || 0 };
          setSubletDb((prevDb) => {
            const idx = prevDb.findIndex((x) => norm(x.subletNo) === norm(data.subletNo) || norm(x.subletName) === norm(data.subletName));
            if (idx >= 0) return prevDb.map((x, i) => i === idx ? { ...x, ...data } : x);
            return [...prevDb, data];
          });
        }
        return next;
      }),
    }));
  };
  const deleteRow = (type, id) => setForm((p) => ({ ...p, [type]: p[type].filter((r) => r.id !== id) }));

  const updateHargaSpareJasa = () => {
    setForm((prev) => ({
      ...prev,
      parts: prev.parts.map((r) => {
        const found = partDb.find((x) => norm(x.partNo) === norm(r.partNo));
        const price = found ? Number(found.price) || 0 : Number(r.price) || 0;
        const qty = Number(r.qty) || 0;
        return { ...r, price, total: qty * price, partName: found?.partName || r.partName };
      }),
      sublets: prev.sublets.map((r) => {
        const found = subletDb.find((x) => norm(x.subletNo) === norm(r.subletNo) || norm(x.subletName) === norm(r.subletName));
        const price = found ? Number(found.price) || 0 : Number(r.price) || 0;
        const qty = Number(r.qty) || 0;
        return { ...r, subletNo: found?.subletNo || r.subletNo, subletName: found?.subletName || r.subletName, price, total: qty * price };
      }),
      jasa: prev.jasa.map((r) => {
        const flatPrice = flatRateDb[repairType] || Number(r.price) || 0;
        const rate = toDecimal(r.rate);
        return { ...r, price: flatPrice, total: rate * flatPrice };
      }),
    }));
    alert("Harga sparepart, sublet, dan jasa sudah diupdate dari master/flat rate.");
  };

  const findCustomerByPlate = (plate) => {
    const q = norm(plate);
    if (!q) return;
    // Auto isi hanya kalau nomor polisi sudah sama persis.
    // Jadi saat baru ketik "DK" data tidak langsung berubah.
    const found = customerDb.find((c) => norm(c.polisi) === q);
    if (found) {
      setForm((p) => ({
        ...p,
        polisi: plate.toUpperCase(),
        kendaraan: found.kendaraan || "",
        rangka: found.rangka || "",
        tahun: found.tahun || "",
        customer: found.customer || "",
        contact: found.contact || "",
        phone: found.phone || "",
        alamat: found.alamat || "",
      }));
    }
  };

  const saveMasterFromCurrent = async (showAlert = true) => {
    const newParts = [...partDb];
    form.parts.forEach((p) => {
      if (!p.partNo) return;
      const idx = newParts.findIndex((x) => x.partNo.toUpperCase() === p.partNo.toUpperCase());
      const data = { partNo: p.partNo, partName: p.partName, price: Number(p.price) || 0 };
      if (idx >= 0) newParts[idx] = { ...newParts[idx], ...data }; else newParts.push(data);
    });

    const newSublets = [...subletDb];
    form.sublets.forEach((p) => {
      if (!p.subletNo && !p.subletName) return;
      const data = { subletNo: p.subletNo || p.subletName, subletName: p.subletName || "-", price: Number(p.price) || 0 };
      const idx = newSublets.findIndex((x) => norm(x.subletNo) === norm(data.subletNo) || norm(x.subletName) === norm(data.subletName));
      if (idx >= 0) newSublets[idx] = { ...newSublets[idx], ...data }; else newSublets.push(data);
    });

    let newCustomers = [...customerDb];
    if (form.polisi) {
      const data = { polisi: form.polisi, kendaraan: form.kendaraan, rangka: form.rangka, tahun: form.tahun, customer: form.customer, contact: form.contact, phone: form.phone, alamat: form.alamat };
      const idx = newCustomers.findIndex((x) => norm(x.polisi) === norm(form.polisi));
      if (idx >= 0) newCustomers = newCustomers.map((x, i) => i === idx ? { ...x, ...data } : x);
      else newCustomers.push(data);
    }

    setPartDb(newParts);
    setSubletDb(newSublets);
    setCustomerDb(newCustomers);

    if (!isSupabaseConfigured) {
      if (showAlert) alert("Database tersimpan di perangkat. Hubungkan Supabase melalui file .env untuk penyimpanan online.");
      return;
    }

    try {
      const partsForDb = newParts.filter((p) => p.partNo).map(partToDb);
      const subletsForDb = newSublets.filter((s) => s.subletNo || s.subletName).map(subletToDb);
      const customersForDb = newCustomers.filter((c) => c.polisi).map(customerToDb);

      if (partsForDb.length) {
        const { error } = await supabase.from("spareparts").upsert(partsForDb, { onConflict: "part_no" });
        if (error) throw error;
      }

      if (subletsForDb.length) {
        const { error } = await supabase.from("sublets").upsert(subletsForDb, { onConflict: "sublet_no" });
        if (error) throw error;
      }

      if (customersForDb.length) {
        const { error } = await supabase.from("customers").upsert(customersForDb, { onConflict: "polisi" });
        if (error) throw error;
      }

      if (showAlert) alert("Database sparepart, sublet, dan customer sudah disimpan online di Supabase.");
    } catch (err) {
      console.error(err);
      if (showAlert) alert("Data tersimpan di browser, tapi gagal simpan ke Supabase. Cek RLS policy / internet.");
    }
  };

  const saveHistory = async () => {
    await saveMasterFromCurrent(false);
    const data = { id: form.id || uid(), ...form, grandTotal: totals.grandTotal, createdAt: form.createdAt || new Date().toLocaleString("id-ID"), updatedAt: new Date().toLocaleString("id-ID") };
    setHistory((prev) => prev.some((x) => x.id === data.id) ? prev.map((x) => x.id === data.id ? data : x) : [data, ...prev]);
    setForm(data);

    if (!isSupabaseConfigured) {
      alert("Estimasi tersimpan di perangkat. Supabase belum dihubungkan.");
      return;
    }

    try {
      const row = { data, grand_total: totals.grandTotal };
      let saved;
      if (isUuid(data.id)) {
        const { data: res, error } = await supabase.from("estimasi_history").upsert({ id: data.id, ...row }).select().single();
        if (error) throw error;
        saved = res;
      } else {
        const { data: res, error } = await supabase.from("estimasi_history").insert(row).select().single();
        if (error) throw error;
        saved = res;
      }
      if (saved?.id) {
        const synced = { ...data, id: saved.id };
        setForm(synced);
        setHistory((prev) => prev.some((x) => x.id === synced.id) ? prev.map((x) => x.id === synced.id ? synced : x) : [synced, ...prev.filter((x) => x.id !== data.id)]);
      }
      alert("Estimasi masuk history online dan bisa diedit lagi.");
    } catch (err) {
      console.error(err);
      alert("Estimasi tersimpan di browser, tapi gagal simpan ke Supabase. Cek RLS policy / internet.");
    }
  };

  const resetForm = () => setForm((prev) => ({ ...emptyForm, staff: prev.staff || emptyForm.staff, jabatan: prev.jabatan || "Service Advisor", kepalaBengkel: prev.kepalaBengkel || emptyForm.kepalaBengkel }));
  const editHistory = (h) => { setForm(h); setPage("estimasi"); };
  const pilihAdvisor = (nama) => {
    const found = advisorDb.find((x) => x.nama === nama);
    if (!found) return;
    if (found.role === "KABENG") setField("kepalaBengkel", found.nama);
    else setForm((prev) => ({ ...prev, staff: found.nama, jabatan: found.jabatan || "Service Advisor" }));
  };

  const parsePartText = (text) => {
    const cleanLine = (line) => String(line || "")
      .replace(/[|]/g, " ")
      .replace(/\b(RP|IDR)\b/gi, " ")
      .replace(/[,]/g, ".")
      .replace(/\s+/g, " ")
      .trim();

    const isHeader = (line) => /part\s*no|part\s*name|retail\s*price|stock|model|qty|total|price/i.test(line);
    const findPrice = (line) => {
      const nums = [...line.matchAll(/\b\d{1,3}(?:[.]\d{3})+\b|\b\d{4,9}\b/g)]
        .map((m) => ({ raw: m[0], value: toNumber(m[0]) }))
        .filter((x) => x.value >= 1000 && x.value <= 5000000);
      if (!nums.length) return null;
      return nums[nums.length - 1];
    };

    const lines = String(text || "").split(/\n/).map(cleanLine).filter(Boolean).filter((x)=>!isHeader(x));
    const joinedRows = [];
    for (let i = 0; i < lines.length; i++) {
      let line = lines[i];
      const hasPart = /\b[0-9A-Z]{5}[-\s]?[0-9A-Z]{4,6}\b/i.test(line);
      const hasPrice = !!findPrice(line);
      // Jika OCR memecah nama/harga ke baris berikutnya, gabungkan maksimal 2 baris.
      if (hasPart && !hasPrice && lines[i + 1]) {
        line = `${line} ${lines[i + 1]}`;
        i++;
        if (!findPrice(line) && lines[i + 1]) { line = `${line} ${lines[i + 1]}`; i++; }
      }
      joinedRows.push(line);
    }

    const result = [];
    for (const lineRaw of joinedRows) {
      const line = cleanLine(lineRaw);
      const partMatch = line.match(/\b[0-9A-Z]{5}[-\s]?[0-9A-Z]{4,6}\b/i);
      if (!partMatch) continue;
      const partNo = partMatch[0].replace(/\s+/g, "-").toUpperCase();
      const priceObj = findPrice(line);
      if (!priceObj) continue;
      let price = priceObj.value;
      if (price > 5000000) price = Math.round(price / 100);

      let name = line
        .replace(partMatch[0], " ")
        .replace(priceObj.raw, " ")
        .replace(/available|not available|retail price|stock depo|stock cpd|depo|cpd|pcs|pc/gi, " ")
        .replace(/\b\d{1,3}\b/g, " ")
        .replace(/[^0-9A-Z .\-/]/gi, " ")
        .replace(/\s+/g, " ")
        .trim();
      if (!name || name.length < 2) name = "-";
      result.push({ id: uid(), free: false, partNo, partName: name, qty: 1, price, total: price });
    }
    return result;
  };

  const addPartsFromImage = async (file) => {
    if (!file) return;
    const res = await Tesseract.recognize(file, "eng");
    const rows = parsePartText(res.data.text);
    setForm((p) => ({ ...p, parts: [...p.parts, ...rows] }));
    setPartDb((prev) => {
      const db = [...prev]; rows.forEach((r) => { const i = db.findIndex((x) => x.partNo === r.partNo); const d = { partNo: r.partNo, partName: r.partName, price: r.price }; if (i >= 0) db[i] = d; else db.push(d); }); return db;
    });
    alert(`${rows.length} part berhasil dibaca dari gambar.`);
  };

  const handlePaste = async (e) => {
    const item = [...e.clipboardData.items].find((i) => i.type.startsWith("image/"));
    if (item && page === "estimasi") addPartsFromImage(item.getAsFile());
  };

  const downloadPDF = async () => {
    await saveHistory();
    const canvas = await html2canvas(pdfRef.current, { scale: 3, useCORS: true, scrollY: 0 });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const imgWidth = 190;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    pdf.addImage(imgData, "PNG", 10, 8, imgWidth, imgHeight);
    pdf.save(`estimasi-${form.polisi || "baru"}.pdf`);
  };

  const menuLabel = (icon, text) => <><span style={styles.menuIcon}>{icon}</span>{!sidebarMini && <span>{text}</span>}</>;
  const isDatabasePage = ["sparepart", "sublet", "jasa", "advisor", "customer"].includes(page);

  return <div onPaste={handlePaste} style={styles.app}>
    <aside style={{...styles.sidebar, ...(sidebarMini ? styles.sidebarMini : {})}}>
      <div style={styles.sidebarHeader}>
        <div style={{...styles.logo, ...(sidebarMini ? styles.logoMini : {})}}>WS</div>
        <button
          type="button"
          title={sidebarMini ? "Maksimalkan menu" : "Minimalkan menu"}
          aria-label={sidebarMini ? "Maksimalkan menu" : "Minimalkan menu"}
          onClick={()=>setSidebarMini((v)=>!v)}
          style={styles.sidebarToggle}
        >{sidebarMini ? "»" : "«"}</button>
      </div>

      <button style={styles.navButton} onClick={()=>setPage("estimasi")} title="Home">
        {menuLabel("⌂", "Home")}
      </button>

      {!sidebarMini && <div style={styles.sectionTitle}>ESTIMASI</div>}
      <button style={page==="estimasi"?styles.menuOn:styles.menu} onClick={()=>setPage("estimasi")} title="Buat Estimasi">
        {menuLabel("▣", "Buat Estimasi")}
      </button>
      <button style={page==="history"?styles.menuOn:styles.menu} onClick={()=>setPage("history")} title="History Estimasi">
        {menuLabel("↻", "History Estimasi")}
      </button>

      <button
        type="button"
        style={isDatabasePage ? styles.databaseHeaderOn : styles.databaseHeader}
        onClick={()=>setDatabaseOpen((v)=>!v)}
        title="Database"
      >
        {menuLabel("🗄", "Database")}
        {!sidebarMini && <span style={styles.chevron}>{databaseOpen ? "▾" : "▸"}</span>}
      </button>

      {(databaseOpen || sidebarMini) && <div style={sidebarMini ? styles.databaseItemsMini : styles.databaseItems}>
        <button style={page==="sparepart"?styles.subMenuOn:styles.subMenu} onClick={()=>setPage("sparepart")} title="Master Sparepart">
          {menuLabel("🔧", "Master Sparepart")}
        </button>
        <button style={page==="sublet"?styles.subMenuOn:styles.subMenu} onClick={()=>setPage("sublet")} title="Master Sublet">
          {menuLabel("🔨", "Master Sublet")}
        </button>
        <button style={page==="jasa"?styles.subMenuOn:styles.subMenu} onClick={()=>setPage("jasa")} title="Update Harga Jasa">
          {menuLabel("🧰", "Harga Jasa")}
        </button>
        <button style={page==="advisor"?styles.subMenuOn:styles.subMenu} onClick={()=>setPage("advisor")} title="Master Advisor">
          {menuLabel("👨‍💼", "Master Advisor")}
        </button>
        <button style={page==="customer"?styles.subMenuOn:styles.subMenu} onClick={()=>setPage("customer")} title="Master Customer">
          {menuLabel("👤", "Master Customer")}
        </button>
      </div>}
    </aside>
    <main style={styles.main}><div style={{...styles.syncBar, background:isSupabaseConfigured ? "#e8f7ee" : "#fff4d6", color:isSupabaseConfigured ? "#176b3a" : "#8a5a00"}}><b>{isSupabaseConfigured ? "☁" : "💾"} {syncStatus}</b><span>{isSupabaseConfigured ? "Data lokal tetap menjadi cadangan otomatis." : "Isi file .env agar tersimpan online di Supabase."}</span></div>{page==="estimasi" && <Estimasi form={form} setField={setField} addPart={addPart} updateRow={updateRow} deleteRow={deleteRow} addSublet={addSublet} addJasa={addJasa} totals={totals} repairType={repairType} setRepairType={setRepairType} handleFlatRateChange={handleFlatRateChange} flatRateDb={flatRateDb} partDb={partDb} subletDb={subletDb} advisorDb={advisorDb} pilihAdvisor={pilihAdvisor} customerDb={customerDb} findCustomerByPlate={findCustomerByPlate} saveMasterFromCurrent={saveMasterFromCurrent} saveHistory={saveHistory} updateHargaSpareJasa={updateHargaSpareJasa} downloadPDF={downloadPDF} resetForm={resetForm} filePartRef={filePartRef} addPartsFromImage={addPartsFromImage} pdfRef={pdfRef}/>} {page==="history" && <History history={history} editHistory={editHistory} setHistory={setHistory} newForm={() => {resetForm(); setPage("estimasi")}}/>} {page==="sparepart" && <MasterPart partDb={partDb} setPartDb={setPartDb}/>} {page==="sublet" && <MasterSublet subletDb={subletDb} setSubletDb={setSubletDb}/>} {page==="jasa" && <MasterJasa flatRateDb={flatRateDb} setFlatRateDb={setFlatRateDb} setSyncStatus={setSyncStatus}/>} {page==="advisor" && <MasterAdvisor advisorDb={advisorDb} setAdvisorDb={setAdvisorDb}/>} {page==="customer" && <MasterCustomer customerDb={customerDb} setCustomerDb={setCustomerDb}/>}</main>
  </div>;
}

function Estimasi(p){ const f=p.form; const customers = p.customerDb || []; return <><section style={styles.card}><h2 style={{textAlign:"center"}}>FORM ESTIMASI</h2><div style={styles.tabs}><b>Profile</b><b>Estimasi Biaya</b></div><h3>🚙 Informasi Kendaraan</h3><div style={styles.grid4}><SearchInput label="No Polisi *" value={f.polisi} suggestions={customers.map((c)=>({value:c.polisi||"",label:`${c.polisi || ""} - ${c.customer || ""} - ${c.kendaraan || ""}`}))} onChange={(v)=>{ const plat = String(v || "").toUpperCase(); p.setField("polisi", plat); p.findCustomerByPlate(plat); }} onSelect={(v)=>{ const plat = String(v || "").toUpperCase(); p.setField("polisi", plat); p.findCustomerByPlate(plat); }}/><SearchInput label="Type Kendaraan *" value={f.kendaraan} suggestions={[...new Set(customers.map(c=>c.kendaraan).filter(Boolean))].map((x)=>({value:x,label:x}))} onChange={(v)=>p.setField("kendaraan",v)} onSelect={(v)=>p.setField("kendaraan",v)}/><SearchInput label="No Rangka *" value={f.rangka} suggestions={customers.map((c)=>({value:c.rangka||"",label:`${c.rangka || ""} - ${c.polisi || ""} - ${c.customer || ""}`}))} onChange={(v)=>p.setField("rangka",v)} onSelect={(v)=>p.setField("rangka",v)}/><Input label="Tahun *" value={f.tahun} onChange={(v)=>p.setField("tahun",v)}/></div><h3>👤 Informasi Pelanggan</h3><div style={styles.grid2}><Input label="Nama Pelanggan *" value={f.customer} onChange={(v)=>p.setField("customer",v)}/><Input label="No Telepon" value={f.phone} onChange={(v)=>p.setField("phone",v)}/><Input label="Contact Person" value={f.contact} onChange={(v)=>p.setField("contact",v)}/><Input label="Alamat" value={f.alamat} onChange={(v)=>p.setField("alamat",v)}/></div><label style={{...styles.label,display:"block",marginTop:14}}>Catatan / Keterangan Tambahan<textarea value={f.catatan || ""} onChange={(e)=>p.setField("catatan",e.target.value)} style={styles.noteInput} placeholder="Ketik catatan yang ingin muncul di kolom kosong PDF..."/></label><h3>▣ Informasi Pembuat Estimasi</h3><div style={styles.grid3}><AdvisorSelect label="Nama Service Advisor *" value={f.staff} advisors={p.advisorDb || []} role="SA" onChange={(v)=>{p.setField("staff",v);p.pilihAdvisor(v)}}/><Input label="Jabatan" value={f.jabatan} onChange={(v)=>p.setField("jabatan",v)}/><AdvisorSelect label="Kepala Bengkel" value={f.kepalaBengkel} advisors={p.advisorDb || []} role="KABENG" onChange={(v)=>{p.setField("kepalaBengkel",v);p.pilihAdvisor(v)}}/></div></section>
  <section style={styles.card}><h3>🔧 Estimasi Parts</h3><table style={styles.table}><thead><tr><th>FREE</th><th>PART NO</th><th>PART NAME</th><th>QTY</th><th>PRICE</th><th>TOTAL</th><th>ACT</th></tr></thead><tbody>{f.parts.map(r=><tr key={r.id}><td><input type="checkbox" checked={r.free} onChange={(e)=>p.updateRow("parts",r.id,"free",e.target.checked)}/></td><td><SearchCell value={r.partNo} suggestions={p.partDb.map(x=>({value:x.partNo,label:`${x.partNo} - ${x.partName} - Rp ${rupiah(x.price)}`}))} onChange={(v)=>p.updateRow("parts",r.id,"partNo",v)} onSelect={(v)=>p.updateRow("parts",r.id,"partNo",v)}/></td><td><SearchCell value={r.partName} suggestions={p.partDb.map(x=>({value:x.partName,label:`${x.partName} - ${x.partNo} - Rp ${rupiah(x.price)}`}))} onChange={(v)=>p.updateRow("parts",r.id,"partName",v)} onSelect={(v)=>p.updateRow("parts",r.id,"partName",v)}/></td><td><input type="number" value={r.qty} onChange={(e)=>p.updateRow("parts",r.id,"qty",e.target.value)} style={styles.smallInput}/></td><td><input value={r.price} onChange={(e)=>p.updateRow("parts",r.id,"price",toNumber(e.target.value))} style={styles.cellInput}/></td><td><b>{rupiah(r.total)}</b></td><td><button onClick={()=>p.deleteRow("parts",r.id)} style={styles.del}>🗑</button></td></tr>)}</tbody></table><button onClick={p.addPart} style={styles.btn}>⊕ Add Part</button><button onClick={()=>p.filePartRef.current.click()} style={styles.green}>♻ Add from Image / Paste Foto</button><input ref={p.filePartRef} type="file" accept="image/*" hidden onChange={(e)=>p.addPartsFromImage(e.target.files[0])}/><small style={{display:"block",marginTop:8}}>Tips: bisa juga copy gambar tabel part lalu klik area aplikasi dan tekan Ctrl+V.</small><hr/>
  <h3>🔨 Estimasi Sublet / Additional Job</h3><table style={styles.table}><thead><tr><th>FREE</th><th>KODE</th><th>NAMA SUBLET</th><th>QTY</th><th>PRICE</th><th>TOTAL</th><th>ACT</th></tr></thead><tbody>{f.sublets.map(r=><tr key={r.id}><td><input type="checkbox" checked={r.free || false} onChange={(e)=>p.updateRow("sublets",r.id,"free",e.target.checked)}/></td><td><SearchCell value={r.subletNo} suggestions={(p.subletDb || []).map(x=>({value:x.subletNo,label:`${x.subletNo} - ${x.subletName} - Rp ${rupiah(x.price)}`}))} onChange={(v)=>p.updateRow("sublets",r.id,"subletNo",v)} onSelect={(v)=>p.updateRow("sublets",r.id,"subletNo",v)}/></td><td><SearchCell value={r.subletName} suggestions={(p.subletDb || []).map(x=>({value:x.subletName,label:`${x.subletName} - ${x.subletNo} - Rp ${rupiah(x.price)}`}))} onChange={(v)=>p.updateRow("sublets",r.id,"subletName",v)} onSelect={(v)=>p.updateRow("sublets",r.id,"subletName",v)}/></td><td><input type="number" value={r.qty} onChange={(e)=>p.updateRow("sublets",r.id,"qty",e.target.value)} style={styles.smallInput}/></td><td><input value={r.price} onChange={(e)=>p.updateRow("sublets",r.id,"price",toNumber(e.target.value))} style={styles.cellInput}/></td><td><b>{rupiah(r.total)}</b></td><td><button onClick={()=>p.deleteRow("sublets",r.id)} style={styles.del}>🗑</button></td></tr>)}</tbody></table><button onClick={p.addSublet} style={styles.btn}>⊕ Add Sublet</button><hr/><h3>🧰 Jasa Pekerjaan</h3><div style={styles.flatRateBox}><b>Flat Rate</b><span>Pilih Type</span><select value={p.repairType || "Tidak Ada"} onChange={(e)=>p.handleFlatRateChange(e.target.value)} style={styles.select}>{Object.keys(p.flatRateDb || {}).map(x=><option key={x} value={x}>{x}</option>)}</select><span>Flat Rate</span><input readOnly value={rupiah((p.flatRateDb || {})[p.repairType] || 0)} style={styles.flatRateInput}/></div><EditableSimple rows={f.jasa} type="jasa" updateRow={p.updateRow} deleteRow={p.deleteRow} cols={["jasaName","rate","price"]} repairType={p.repairType}/><button onClick={p.addJasa} style={styles.btn}>⊕ Add Jasa</button><div style={styles.discount}><Input label="Disc Part (%)" value={f.discPartPct} onChange={(v)=>p.setField("discPartPct",v)}/><Input label="Disc Part (Rp)" value={f.discPartRp} onChange={(v)=>p.setField("discPartRp",toNumber(v))}/><Input label="Disc Jasa (%)" value={f.discJasaPct} onChange={(v)=>p.setField("discJasaPct",v)}/><Input label="Disc Jasa (Rp)" value={f.discJasaRp} onChange={(v)=>p.setField("discJasaRp",toNumber(v))}/><div style={styles.totalBox}><p>Total Parts<br/><b>Rp {rupiah(p.totals.totalParts)}</b></p><p>Total Sublet<br/><b>Rp {rupiah(p.totals.totalSublet)}</b></p><p>Total Jasa<br/><b>Rp {rupiah(p.totals.totalJasa)}</b></p><b>Grand Total</b><h2>Rp {rupiah(p.totals.grandTotal)}</h2></div></div><div style={styles.actions}><button onClick={p.resetForm} style={styles.red}>↻ Reset</button><button onClick={p.updateHargaSpareJasa} style={styles.btn}>↻ Update Harga Spare & Jasa</button><button onClick={p.saveMasterFromCurrent} style={styles.btn}>💾 Save Master</button><button onClick={p.saveHistory} style={styles.green}>Submit / Save History</button><button onClick={p.downloadPDF} style={styles.blue}>Submit & Create PDF</button></div></section><PDFView refx={p.pdfRef} form={f} totals={p.totals}/></> }

function AdvisorSelect({label,value,advisors=[],role,onChange}){
  const wanted = String(role || "SA").toUpperCase();
  const items = (advisors || [])
    .filter((x) => x && x.aktif !== false)
    .filter((x) => {
      const r = String(x.role || x.jabatan || "SA").toUpperCase();
      return wanted === "KABENG" ? (r.includes("KABENG") || /kepala/i.test(x.jabatan || "")) : !(r.includes("KABENG") || /kepala/i.test(x.jabatan || ""));
    })
    .filter((x, i, arr) => x.nama && arr.findIndex((y) => norm(y.nama) === norm(x.nama)) === i);
  const currentExists = items.some((x) => x.nama === value);
  return <label style={styles.label}>{label}<select value={value || ""} onChange={(e)=>onChange(e.target.value)} style={styles.input}>
    <option value="">-- Pilih {wanted === "KABENG" ? "Kepala Bengkel" : "Service Advisor"} --</option>
    {value && !currentExists && <option value={value}>{value} (data lama)</option>}
    {items.map((x)=><option key={`${wanted}-${x.id || x.nama}`} value={x.nama}>{x.nama}{x.jabatan ? ` - ${x.jabatan}` : ""}</option>)}
  </select><small style={{display:"block",marginTop:5,color:"#666"}}>{items.length} nama aktif tersedia dari Master Advisor.</small></label>
}

function SearchInput({label,value,onChange,onSelect,suggestions=[]}){
  const [open,setOpen]=useState(false);
  const q=norm(value);
  const items=(suggestions||[]).filter(x=>norm(x.value).includes(q)||norm(x.label).includes(q)).slice(0,30);
  return <label style={{...styles.label,position:"relative",display:"block"}}>{label}<input value={value||""} onChange={(e)=>{onChange(e.target.value);setOpen(true)}} onFocus={()=>setOpen(true)} onBlur={()=>setTimeout(()=>setOpen(false),180)} style={styles.input}/>{open&&items.length>0&&<div style={styles.suggestBox}>{items.map((x,i)=><div key={(x.value||"")+i} onMouseDown={(e)=>{e.preventDefault();onSelect?onSelect(x.value):onChange(x.value);setOpen(false)}} style={styles.suggestItem}>{x.label||x.value}</div>)}</div>}</label>
}
function SearchCell({value,onChange,onSelect,suggestions=[]}){
  const [open,setOpen]=useState(false);
  const q=norm(value);
  const items=(suggestions||[]).filter(x=>norm(x.value).includes(q)||norm(x.label).includes(q)).slice(0,30);
  return <div style={{position:"relative"}}><input value={value||""} onChange={(e)=>{onChange(e.target.value);setOpen(true)}} onFocus={()=>setOpen(true)} onBlur={()=>setTimeout(()=>setOpen(false),180)} style={styles.cellInput}/>{open&&items.length>0&&<div style={styles.suggestBox}>{items.map((x,i)=><div key={(x.value||"")+i} onMouseDown={(e)=>{e.preventDefault();onSelect?onSelect(x.value):onChange(x.value);setOpen(false)}} style={styles.suggestItem}>{x.label||x.value}</div>)}</div>}</div>
}
function EditableSimple({rows,type,updateRow,deleteRow,cols,repairType}){return <table style={styles.table}><tbody>{rows.map(r=><tr key={r.id}>{cols.map(c=>{ const lockedJasaPrice = type === "jasa" && c === "price" && repairType && repairType !== "Tidak Ada"; return <td key={c}><input value={r[c]||""} readOnly={lockedJasaPrice} onChange={(e)=>updateRow(type,r.id,c,c.includes("price")?toNumber(e.target.value):e.target.value)} style={lockedJasaPrice ? {...styles.cellInput, background:"#eee", fontWeight:"bold"} : styles.cellInput} placeholder={c}/></td>})}<td><b>{rupiah(r.total)}</b></td><td><button onClick={()=>deleteRow(type,r.id)} style={styles.del}>🗑</button></td></tr>)}</tbody></table>}
function Input({label,value,onChange,list}){return <label style={styles.label}>{label}<input list={list} value={value||""} onChange={(e)=>onChange(e.target.value)} style={styles.input}/></label>}
function History({history,editHistory,setHistory,newForm}){
  const [q, setQ] = useState("");
  const key = norm(q);
  const filtered = !key ? history : history.filter((h) => {
    const gabung = [
      h.polisi, h.customer, h.kendaraan, h.rangka, h.tahun, h.phone, h.contact, h.alamat,
      h.createdAt, h.updatedAt, h.grandTotal
    ].join(" ");
    return norm(gabung).includes(key);
  });

  return <section style={styles.card}>
    <button style={styles.greenRight} onClick={newForm}>+ Buat Estimasi Baru</button>
    <h1>History Estimasi</h1>
    <div style={{margin:"12px 0 16px"}}>
      <input
        value={q}
        onChange={(e)=>setQ(e.target.value)}
        placeholder="Cari history: plat nomor, nama customer, type kendaraan, no rangka, telp, alamat..."
        style={{...styles.input, maxWidth:650}}
      />
      <small style={{display:"block",marginTop:6}}>
        Hasil: {filtered.length} dari {history.length} data
      </small>
    </div>
    <table style={styles.table}>
      <thead><tr><th>No</th><th>No Polisi</th><th>Pelanggan</th><th>Type</th><th>Grand Total</th><th>Dibuat</th><th>Update</th><th>Action</th></tr></thead>
      <tbody>{filtered.length===0?<tr><td colSpan="8" style={{textAlign:"center",padding:30}}>Data tidak ditemukan.</td></tr>:filtered.map((h,i)=><tr key={h.id}><td>{i+1}</td><td>{h.polisi}</td><td>{h.customer}</td><td>{h.kendaraan}</td><td>Rp {rupiah(h.grandTotal)}</td><td>{h.createdAt}</td><td>{h.updatedAt}</td><td><button onClick={()=>editHistory(h)} style={styles.btn}>Edit</button><button onClick={()=>editHistory({...h,id:uid(),createdAt:new Date().toLocaleString("id-ID"),updatedAt:new Date().toLocaleString("id-ID")})} style={styles.btn}>Copy</button><button onClick={()=>setHistory(history.filter(x=>x.id!==h.id))} style={styles.del}>Hapus</button></td></tr>)}</tbody>
    </table>
  </section>
}
function parseImportRows(text) {
  return String(text || "")
    .split(/\n/)
    .map((x) => x.trim())
    .filter(Boolean)
    .map((line) => line.split(/\t|;/).map((x) => x.trim()).filter((_, i, arr) => arr.length > 1 || i === 0));
}

function MasterPart({partDb,setPartDb}){
  const [bulk, setBulk] = useState("");
  const [bulkHarga, setBulkHarga] = useState("");
  const importBulk = () => {
    const rows = parseImportRows(bulk);
    const next = [...partDb];
    rows.forEach((cols) => {
      if (cols.length < 2) return;
      const [partNo, partName, priceRaw] = cols;
      if (/part\s*no/i.test(partNo)) return;
      const data = { partNo, partName, price: toNumber(priceRaw || 0) };
      if (!data.partNo) return;
      const idx = next.findIndex((x) => (x.partNo || "").toUpperCase() === data.partNo.toUpperCase());
      if (idx >= 0) next[idx] = { ...next[idx], ...data }; else next.push(data);
    });
    setPartDb(next);
    setBulk("");
    alert(`${rows.length} baris sparepart diproses.`);
  };
  const updateHargaBulk = async () => {
    const rows = parseImportRows(bulkHarga);
    if (!rows.length) {
      alert("Paste data perubahan harga dulu. Format: Part No | Part Name | Price");
      return;
    }

    let processed = 0;
    const next = [...partDb];

    rows.forEach((cols) => {
      if (cols.length < 2) return;
      const [partNo, partNameOrPrice, priceRaw] = cols;
      if (/part\s*no/i.test(partNo)) return;

      const price = priceRaw !== undefined ? toNumber(priceRaw) : toNumber(partNameOrPrice);
      const partName = priceRaw !== undefined ? partNameOrPrice : "";
      if (!partNo || !price) return;

      const idx = next.findIndex((x) => norm(x.partNo) === norm(partNo));
      if (idx >= 0) {
        next[idx] = {
          ...next[idx],
          partNo,
          partName: partName || next[idx].partName || "-",
          price,
        };
      } else {
        next.push({ partNo, partName: partName || "-", price });
      }
      processed++;
    });

    setPartDb(next);
    setBulkHarga("");

    try {
      const rowsForDb = next.filter((p) => p.partNo).map(partToDb);
      if (rowsForDb.length) {
        const { error } = await supabase.from("spareparts").upsert(rowsForDb, { onConflict: "part_no" });
        if (error) throw error;
      }
      alert(`${processed} harga sparepart diproses dan disimpan online.`);
    } catch (err) {
      console.error(err);
      alert(`${processed} harga diproses di aplikasi, tapi gagal simpan online. Cek RLS policy / CORS.`);
    }
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(partDb, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = "master-sparepart.json"; a.click(); URL.revokeObjectURL(url);
  };
  const saveOnline = async () => {
    try {
      const rows = partDb.filter((p) => p.partNo).map(partToDb);
      if (rows.length) {
        const { error } = await supabase.from("spareparts").upsert(rows, { onConflict: "part_no" });
        if (error) throw error;
      }
      alert("Harga sparepart sudah disimpan/update ke Supabase.");
    } catch (err) {
      console.error(err);
      alert("Gagal update sparepart ke Supabase. Cek RLS policy / CORS.");
    }
  };
  const deleteAll = async () => {
    if (!confirm("Hapus semua master sparepart?")) return;
    setPartDb([]);
    localStorage.removeItem("sparepart_db_v5");
    try {
      const { error } = await supabase.from("spareparts").delete().neq("part_no", "__never__");
      if (error) throw error;
      alert("Semua master sparepart sudah dihapus dari aplikasi dan Supabase.");
    } catch (err) {
      console.error(err);
      alert("Sparepart di aplikasi sudah kosong, tapi gagal hapus di Supabase. Cek RLS policy / CORS.");
    }
  };
  return <section style={styles.card}><h1>Master Sparepart</h1>
    <p><b>Input banyak sekaligus:</b> copy dari Excel lalu paste di bawah. Format: Part No | Part Name | Price.</p>
    <textarea value={bulk} onChange={(e)=>setBulk(e.target.value)} placeholder={'Contoh dari Excel:\n08880-85986\tTMO 10W-30 SN 1L\t117000\n15601-BZ030\tOIL FILTER\t30000'} style={styles.bulkBox}/>
    <button style={styles.green} onClick={importBulk}>Import Sparepart Banyak</button>
    <button style={styles.btn} onClick={saveOnline}>Update Harga Online</button>
    <div style={{marginTop:18,padding:12,border:"1px solid #ddd",borderRadius:8,background:"#fafafa"}}>
      <b>Update Harga Sparepart</b>
      <p style={{margin:"6px 0 8px"}}>Paste dari Excel jika ada perubahan harga. Format: Part No | Part Name | Price, atau Part No | Price.</p>
      <textarea value={bulkHarga} onChange={(e)=>setBulkHarga(e.target.value)} placeholder={'Contoh:\n08880-85986\tTMO 10W-30 SN 1L\t120000\n15601-BZ030\t35000'} style={styles.bulkBox}/>
      <button style={styles.blue} onClick={updateHargaBulk}>Update Harga Sparepart</button>
    </div>
    <button style={styles.red} onClick={deleteAll}>Delete All Sparepart</button>
    <button style={styles.btn} onClick={exportJson}>Export Backup</button>
    <button style={styles.btn} onClick={()=>setPartDb([...partDb,{partNo:"",partName:"",price:0}])}>+ Add Sparepart</button>
    <table style={styles.table}><thead><tr><th>Part No</th><th>Part Name</th><th>Price</th><th>Act</th></tr></thead><tbody>{partDb.map((p,i)=><tr key={i}><td><input value={p.partNo} onChange={e=>setPartDb(partDb.map((x,j)=>j===i?{...x,partNo:e.target.value}:x))} style={styles.cellInput}/></td><td><input value={p.partName} onChange={e=>setPartDb(partDb.map((x,j)=>j===i?{...x,partName:e.target.value}:x))} style={styles.cellInput}/></td><td><input value={p.price} onChange={e=>setPartDb(partDb.map((x,j)=>j===i?{...x,price:toNumber(e.target.value)}:x))} style={styles.cellInput}/></td><td><button style={styles.del} onClick={()=>setPartDb(partDb.filter((_,j)=>j!==i))}>Hapus</button></td></tr>)}</tbody></table></section>
}


function MasterSublet({subletDb,setSubletDb}){
  const [bulk, setBulk] = useState("");
  const [bulkHarga, setBulkHarga] = useState("");
  const [busy, setBusy] = useState(false);
  const [syncMessage, setSyncMessage] = useState("");
  const importBulk = async () => {
    const rows = parseImportRows(bulk);
    const next = [...subletDb];
    let processed = 0;
    rows.forEach((cols) => {
      if (cols.length < 2) return;
      const [subletNo, subletName, priceRaw] = cols;
      if (/sublet|kode|nama/i.test(subletNo)) return;
      const data = { subletNo: subletNo || subletName, subletName: subletName || "-", price: toNumber(priceRaw || 0) };
      if (!data.subletNo && !data.subletName) return;
      const idx = next.findIndex((x) => norm(x.subletNo) === norm(data.subletNo) || norm(x.subletName) === norm(data.subletName));
      if (idx >= 0) next[idx] = { ...next[idx], ...data }; else next.push(data);
      processed++;
    });
    setSubletDb(next);
    setBulk("");
    await saveSubletOnline(next, `${processed} baris sublet diproses dan disimpan online.`);
  };
  const updateHargaBulk = async () => {
    const rows = parseImportRows(bulkHarga);
    if (!rows.length) { alert("Paste data perubahan harga dulu. Format: Kode Sublet | Nama Sublet | Price, atau Nama Sublet | Price"); return; }
    const next = [...subletDb];
    let processed = 0;
    rows.forEach((cols) => {
      if (cols.length < 2) return;
      const [kodeAtauNama, namaAtauHarga, priceRaw] = cols;
      if (/sublet|kode|nama/i.test(kodeAtauNama)) return;
      const price = priceRaw !== undefined ? toNumber(priceRaw) : toNumber(namaAtauHarga);
      const subletName = priceRaw !== undefined ? namaAtauHarga : kodeAtauNama;
      const subletNo = priceRaw !== undefined ? kodeAtauNama : kodeAtauNama;
      if (!subletName || !price) return;
      const idx = next.findIndex((x) => norm(x.subletNo) === norm(subletNo) || norm(x.subletName) === norm(subletName));
      if (idx >= 0) next[idx] = { ...next[idx], subletNo: subletNo || next[idx].subletNo, subletName: subletName || next[idx].subletName, price };
      else next.push({ subletNo: subletNo || subletName, subletName, price });
      processed++;
    });
    setSubletDb(next);
    setBulkHarga("");
    await saveSubletOnline(next, `${processed} harga sublet diproses dan disimpan online.`);
  };
  const saveSubletOnline = async (rowsData = subletDb, successText = "Master sublet sudah disimpan/update ke Supabase.", silent = false) => {
    setBusy(true); setSyncMessage("Memproses dan menyimpan ke Supabase...");
    try {
      if (!isSupabaseConfigured) throw new Error("Supabase belum dikonfigurasi");
      const rows = rowsData.filter((s) => s.subletNo || s.subletName).map(subletToDb);
      if (rows.length) {
        const { error } = await supabase.from("sublets").upsert(rows, { onConflict: "sublet_no" });
        if (error) throw error;
      }
      setSyncMessage(`✅ ${successText}`);
      if (!silent) alert(successText);
      return true;
    } catch (err) {
      console.error(err);
      const message = `❌ Gagal simpan Sublet: ${err?.message || "periksa tabel dan RLS Supabase"}`;
      setSyncMessage(message);
      if (!silent) alert(message);
      return false;
    } finally {
      setBusy(false);
    }
  };
  const refreshOnline = async () => {
    setBusy(true); setSyncMessage("Memuat data Sublet dari Supabase...");
    try {
      const { data, error } = await supabase.from("sublets").select("*").order("sublet_name", { ascending: true });
      if (error) throw error;
      setSubletDb((data || []).map(subletFromDb));
      setSyncMessage(`✅ ${data?.length || 0} Sublet dimuat dari Supabase.`);
    } catch (err) { setSyncMessage(`❌ Gagal memuat Sublet: ${err?.message || "kesalahan"}`); }
    finally { setBusy(false); }
  };
  const deleteOne = async (row, index) => {
    setSubletDb(subletDb.filter((_,j)=>j!==index));
    if (!isSupabaseConfigured || !row.subletNo) return;
    setBusy(true); setSyncMessage("Menghapus Sublet dari Supabase...");
    const { error } = await supabase.from("sublets").delete().eq("sublet_no", row.subletNo);
    setSyncMessage(error ? `❌ Gagal menghapus: ${error.message}` : "✅ Sublet berhasil dihapus.");
    setBusy(false);
  };
  const deleteAll = async () => {
    if (!confirm("Hapus semua master sublet? Data history lama tidak ikut terhapus.")) return;
    setSubletDb([]);
    localStorage.removeItem("sublet_db_v1");
    try {
      const { error } = await supabase.from("sublets").delete().neq("sublet_no", "__never__");
      if (error) throw error;
      alert("Semua master sublet sudah dihapus dari aplikasi dan Supabase. History lama tetap aman.");
    } catch (err) {
      console.error(err);
      alert("Sublet di aplikasi sudah kosong, tapi gagal hapus di Supabase.");
    }
  };
  return <section style={styles.card}><h1>Master Sublet</h1>
    {syncMessage && <div style={{padding:10,marginBottom:10,borderRadius:6,background:syncMessage.startsWith("❌")?"#fee2e2":syncMessage.startsWith("✅")?"#dcfce7":"#dbeafe"}}>{syncMessage}</div>}
    <p><b>Input banyak sekaligus:</b> copy dari Excel lalu paste di bawah. Format: Kode Sublet | Nama Sublet | Price.</p>
    <textarea value={bulk} onChange={(e)=>setBulk(e.target.value)} placeholder={'Contoh dari Excel:\nSBL-001\tSpooring\t250000\nSBL-002\tBalancing\t150000'} style={styles.bulkBox}/>
    <button style={styles.green} disabled={busy} onClick={importBulk}>{busy ? "Memproses..." : "Import Sublet Banyak"}</button>
    <button style={styles.btn} disabled={busy} onClick={()=>saveSubletOnline()}>{busy ? "Memproses..." : "Update Sublet Online"}</button>
    <button style={styles.btn} disabled={busy} onClick={refreshOnline}>{busy ? "Memproses..." : "Refresh dari Supabase"}</button>
    <div style={{marginTop:18,padding:12,border:"1px solid #ddd",borderRadius:8,background:"#fafafa"}}>
      <b>Update Harga Sublet</b>
      <p style={{margin:"6px 0 8px"}}>Paste dari Excel jika ada perubahan harga. Format: Kode Sublet | Nama Sublet | Price, atau Nama Sublet | Price.</p>
      <textarea value={bulkHarga} onChange={(e)=>setBulkHarga(e.target.value)} placeholder={'Contoh:\nSBL-001\tSpooring\t275000\nBalancing\t175000'} style={styles.bulkBox}/>
      <button style={styles.blue} disabled={busy} onClick={updateHargaBulk}>{busy ? "Memproses..." : "Update Harga Sublet"}</button>
    </div>
    <button style={styles.red} onClick={deleteAll}>Delete All Sublet</button>
    <button style={styles.btn} onClick={()=>setSubletDb([...subletDb,{subletNo:"",subletName:"",price:0}])}>+ Add Sublet</button>
    <table style={styles.table}><thead><tr><th>Kode Sublet</th><th>Nama Sublet</th><th>Price</th><th>Act</th></tr></thead><tbody>{subletDb.map((p,i)=><tr key={i}><td><input value={p.subletNo} onChange={e=>setSubletDb(subletDb.map((x,j)=>j===i?{...x,subletNo:e.target.value}:x))} onBlur={()=>saveSubletOnline([p],"Sublet otomatis tersimpan.",true)} style={styles.cellInput}/></td><td><input value={p.subletName} onChange={e=>setSubletDb(subletDb.map((x,j)=>j===i?{...x,subletName:e.target.value}:x))} onBlur={()=>saveSubletOnline([p],"Sublet otomatis tersimpan.",true)} style={styles.cellInput}/></td><td><input value={p.price} onChange={e=>setSubletDb(subletDb.map((x,j)=>j===i?{...x,price:toNumber(e.target.value)}:x))} onBlur={()=>saveSubletOnline([p],"Sublet otomatis tersimpan.",true)} style={styles.cellInput}/></td><td><button style={styles.del} disabled={busy} onClick={()=>deleteOne(p,i)}>Hapus</button></td></tr>)}</tbody></table>
  </section>
}

function MasterJasa({flatRateDb,setFlatRateDb,setSyncStatus}){
  const [namaBaru,setNamaBaru]=useState("");
  const [hargaBaru,setHargaBaru]=useState(0);
  const entries=Object.entries(flatRateDb || {});
  const tambah=()=>{
    const nama=String(namaBaru||"").trim().toUpperCase();
    if(!nama) return alert("Isi nama type jasa terlebih dahulu.");
    setFlatRateDb({...flatRateDb,[nama]:toNumber(hargaBaru)});
    setNamaBaru(""); setHargaBaru(0);
  };
  const saveOnline=async()=>{
    if(!isSupabaseConfigured) return alert("Supabase belum dihubungkan. Salin .env.example menjadi .env lalu isi URL dan Anon Key.");
    try{
      const rows=Object.entries(flatRateDb||{}).filter(([name])=>name).map(laborToDb);
      const {error}=await supabase.from("labor_prices").upsert(rows,{onConflict:"name"});
      if(error) throw error;
      setSyncStatus?.("Supabase tersambung — harga jasa tersimpan online");
      alert("Harga jasa sudah disimpan ke Supabase dan tetap dicadangkan di perangkat.");
    }catch(err){console.error(err);setSyncStatus?.("Gagal simpan harga jasa ke Supabase");alert("Gagal simpan online. Jalankan file supabase_setup_v12.sql di Supabase SQL Editor.");}
  };
  return <section style={styles.card}><h2>🧰 Update Harga Jasa / Flat Rate</h2>
    <p>Harga langsung dipakai pada estimasi, tersimpan di perangkat, dan dapat disinkronkan ke Supabase.</p>
    <div style={styles.grid3}><Input label="Nama Type Jasa" value={namaBaru} onChange={setNamaBaru}/><Input label="Harga Flat Rate" value={hargaBaru} onChange={(v)=>setHargaBaru(toNumber(v))}/><div style={{display:"flex",alignItems:"end"}}><button style={styles.green} onClick={tambah}>+ Tambah Type Jasa</button></div></div>
    <div style={{margin:"12px 0"}}><button style={styles.blue} onClick={saveOnline}>☁ Simpan Harga Jasa ke Supabase</button><button style={styles.btn} onClick={()=>setFlatRateDb(defaultFlatRateList)}>Kembalikan Harga Default</button></div>
    <table style={styles.table}><thead><tr><th>TYPE JASA</th><th>HARGA</th><th>ACT</th></tr></thead><tbody>{entries.map(([nama,harga])=><tr key={nama}><td><b>{nama}</b></td><td><input value={harga} onChange={(e)=>setFlatRateDb({...flatRateDb,[nama]:toNumber(e.target.value)})} style={styles.cellInput}/></td><td>{nama!=="Tidak Ada"&&<button style={styles.del} onClick={()=>{const next={...flatRateDb};delete next[nama];setFlatRateDb(next)}}>Hapus</button>}</td></tr>)}</tbody></table>
  </section>
}

function MasterAdvisor({advisorDb,setAdvisorDb}){
  const [bulk, setBulk] = useState("");
  const importBulk = () => {
    const rows = parseImportRows(bulk);
    const next = [...advisorDb];
    let processed = 0;
    rows.forEach((cols) => {
      if (cols.length < 1) return;
      const [nama, jabatanRaw, roleRaw] = cols;
      if (/nama|advisor|service advisor/i.test(nama)) return;
      if (!nama) return;
      const jabatan = jabatanRaw || "Service Advisor";
      const role = String(roleRaw || jabatan).toUpperCase().includes("KABENG") || /kepala/i.test(jabatan) ? "KABENG" : "SA";
      const data = { nama, jabatan, role, aktif: true };
      const idx = next.findIndex((x) => norm(x.nama) === norm(nama));
      if (idx >= 0) next[idx] = { ...next[idx], ...data }; else next.push(data);
      processed++;
    });
    setAdvisorDb(next);
    setBulk("");
    alert(`${processed} data advisor/kabeng diproses. History lama tidak berubah.`);
  };
  const saveOnline = async () => {
    try {
      const rows = advisorDb.filter((x) => x.nama).map(advisorToDb);
      if (rows.length) {
        const { error } = await supabase.from("advisors").upsert(rows, { onConflict: "nama" });
        if (error) throw error;
      }
      alert("Master Advisor/Kabeng sudah disimpan ke Supabase.");
    } catch (err) {
      console.error(err);
      alert("Data tersimpan di browser, tapi gagal simpan online. Jalankan SQL tabel advisors dulu / cek RLS.");
    }
  };
  const deleteAll = async () => {
    if (!confirm("Hapus semua master advisor/kabeng? Data history lama tidak ikut terhapus.")) return;
    setAdvisorDb([]);
    localStorage.removeItem("advisor_db_v1");
    try {
      const { error } = await supabase.from("advisors").delete().neq("nama", "__never__");
      if (error) throw error;
      alert("Master advisor/kabeng sudah dihapus. History lama tetap aman.");
    } catch (err) {
      console.error(err);
      alert("Advisor di aplikasi sudah kosong, tapi gagal hapus di Supabase.");
    }
  };
  return <section style={styles.card}><h1>Master Advisor / Kabeng</h1>
    <p><b>Input banyak sekaligus:</b> copy dari Excel lalu paste. Format: Nama | Jabatan | Role. Role isi SA atau KABENG.</p>
    <textarea value={bulk} onChange={(e)=>setBulk(e.target.value)} placeholder={"Contoh:\nKomang Ayu Wardani\tService Advisor\tSA\nPande Wira\tService Advisor\tSA\nI Nengah Andika\tKepala Bengkel\tKABENG"} style={styles.bulkBox}/>
    <button style={styles.green} onClick={importBulk}>Import Advisor Banyak</button>
    <button style={styles.btn} onClick={saveOnline}>Update Advisor Online</button>
    <button style={styles.red} onClick={deleteAll}>Delete All Advisor</button>
    <button style={styles.btn} onClick={()=>setAdvisorDb([...advisorDb,{nama:"",jabatan:"Service Advisor",role:"SA",aktif:true}])}>+ Add Advisor</button>
    <table style={styles.table}><thead><tr><th>Nama</th><th>Jabatan</th><th>Role</th><th>Aktif</th><th>Act</th></tr></thead><tbody>{advisorDb.map((a,i)=><tr key={i}>
      <td><input value={a.nama||""} onChange={e=>setAdvisorDb(advisorDb.map((x,j)=>j===i?{...x,nama:e.target.value}:x))} style={styles.cellInput}/></td>
      <td><input value={a.jabatan||""} onChange={e=>setAdvisorDb(advisorDb.map((x,j)=>j===i?{...x,jabatan:e.target.value}:x))} style={styles.cellInput}/></td>
      <td><select value={a.role||"SA"} onChange={e=>setAdvisorDb(advisorDb.map((x,j)=>j===i?{...x,role:e.target.value,jabatan:e.target.value==="KABENG"?(x.jabatan||"Kepala Bengkel"):(x.jabatan||"Service Advisor")}:x))} style={styles.cellInput}><option value="SA">SA</option><option value="KABENG">KABENG</option></select></td>
      <td><input type="checkbox" checked={a.aktif!==false} onChange={e=>setAdvisorDb(advisorDb.map((x,j)=>j===i?{...x,aktif:e.target.checked}:x))}/></td>
      <td><button style={styles.del} onClick={()=>setAdvisorDb(advisorDb.filter((_,j)=>j!==i))}>Hapus</button></td>
    </tr>)}</tbody></table>
  </section>
}

const CUSTOMER_HEADER_ALIASES = {
  polisi: ["POLICE_NO", "POLICE NO", "POLICE", "NO POLISI", "NO_POLISI", "NOPOL", "PLAT", "PLATE"],
  kendaraan: ["MODEL", "KENDARAAN", "TYPE", "TIPE", "VEHICLE"],
  customer: ["CUSTOMER", "NAMA CUSTOMER", "NAMA_CUSTOMER", "PELANGGAN", "NAMA"],
  alamat: ["ADDRESS", "ALAMAT"],
  rangka: ["RANGKA", "NO RANGKA", "NO_RANGKA", "CHASSIS", "CHASSIS_NO", "VIN"],
  phone: ["TELEPHONE_CP", "TELEPHONE CP", "NO TELP", "NO_TELP", "TELEPON", "PHONE", "HP", "WA CP"],
};
const cleanHeader = (v) => String(v || "").trim().toUpperCase().replace(/[^A-Z0-9]+/g, " ").trim();
const findHeaderIndex = (headers, aliases) => {
  const normalized = headers.map(cleanHeader);
  return normalized.findIndex((h) => aliases.some((a) => h === cleanHeader(a)));
};
const rowsToCustomersByHeader = (matrix) => {
  if (!Array.isArray(matrix) || !matrix.length) return [];
  const headerRowIndex = matrix.findIndex((row) => {
    const h = (row || []).map(cleanHeader);
    return h.some((x) => ["POLICE NO", "POLICE", "NO POLISI", "POLICE NO"].includes(x))
      && h.some((x) => ["RANGKA", "NO RANGKA", "VIN", "CHASSIS"].includes(x));
  });
  const start = headerRowIndex >= 0 ? headerRowIndex + 1 : 0;
  const headers = headerRowIndex >= 0 ? matrix[headerRowIndex] : ["POLICE_NO", "MODEL", "CUSTOMER", "ADDRESS", "RANGKA", "TELEPHONE_CP"];
  const indexes = Object.fromEntries(Object.entries(CUSTOMER_HEADER_ALIASES).map(([key, aliases]) => [key, findHeaderIndex(headers, aliases)]));
  // Bila tidak ada header, pakai urutan format standar yang diberikan pengguna.
  if (headerRowIndex < 0) Object.assign(indexes, { polisi:0, kendaraan:1, customer:2, alamat:3, rangka:4, phone:5 });
  return matrix.slice(start).map((row) => ({
    polisi: String(row?.[indexes.polisi] ?? "").trim().toUpperCase(),
    kendaraan: String(row?.[indexes.kendaraan] ?? "").trim(),
    customer: String(row?.[indexes.customer] ?? "").trim(),
    alamat: String(row?.[indexes.alamat] ?? "").trim(),
    rangka: String(row?.[indexes.rangka] ?? "").trim().toUpperCase(),
    phone: String(row?.[indexes.phone] ?? "").trim(),
    contact: "", tahun: "",
  })).filter((x) => x.polisi && !/POLICE|POLISI/i.test(x.polisi));
};

function MasterCustomer({customerDb,setCustomerDb}){
  const [bulk, setBulk] = useState("");
  const excelInputRef = useRef(null);
  const originalPoliceRef = useRef({});
  const [busy, setBusy] = useState(false);
  const [syncMessage, setSyncMessage] = useState("");
  const mergeCustomers = (incoming) => {
    const next = [...customerDb];
    let processed = 0;
    incoming.forEach((data) => {
      if (!String(data.polisi || "").trim()) return;
      const key = norm(data.polisi);
      const idx = next.findIndex((x) => norm(x.polisi) === key);
      if (idx >= 0) next[idx] = { ...next[idx], ...data };
      else next.push(data);
      processed++;
    });
    return { next, processed };
  };
  const saveCustomerOnline = async (rowsData, successText, silent = false) => {
    const validRows = rowsData.filter((c) => String(c.polisi || "").trim()).map(customerToDb);
    if (!validRows.length) {
      if (!silent) alert("Tidak ada data customer yang bisa disimpan. Pastikan Nomor Polisi sudah diisi.");
      return false;
    }
    setBusy(true); setSyncMessage("Memproses dan menyimpan Customer ke Supabase...");
    try {
      if (!isSupabaseConfigured) throw new Error("Supabase belum dikonfigurasi");
      const { error } = await supabase.from("customers").upsert(validRows, { onConflict: "polisi" });
      if (error) throw error;
      const message = successText || `${validRows.length} customer berhasil disimpan ke Supabase.`;
      setSyncMessage(`✅ ${message}`);
      if (!silent) alert(message);
      return true;
    } catch (err) {
      console.error("Gagal menyimpan customer:", err);
      const message = `❌ Gagal simpan Customer: ${err?.message || "kesalahan tidak diketahui"}`;
      setSyncMessage(message);
      if (!silent) alert(message);
      return false;
    } finally {
      setBusy(false);
    }
  };
  const importBulk = async () => {
    const matrix = parseImportRows(bulk);
    if (!matrix.length) { alert("Paste data customer dari Excel terlebih dahulu."); return; }
    const incoming = rowsToCustomersByHeader(matrix);
    const { next, processed } = mergeCustomers(incoming);
    if (!processed) { alert("Tidak ada baris customer yang valid. Pastikan ada kolom POLICE_NO."); return; }
    setCustomerDb(next); setBulk("");
    await saveCustomerOnline(next, `${processed} customer diproses. POLICE_NO dibaca sebagai plat dan RANGKA tetap sebagai nomor rangka.`);
  };
  const importExcel = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data, { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const matrix = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "", raw: false });
      const incoming = rowsToCustomersByHeader(matrix);
      const { next, processed } = mergeCustomers(incoming);
      if (!processed) throw new Error("Kolom POLICE_NO tidak ditemukan atau semua baris kosong");
      setCustomerDb(next);
      await saveCustomerOnline(next, `${processed} customer dari Excel berhasil diimpor dan disinkronkan.`);
    } catch (err) {
      console.error(err);
      alert(`Import Excel gagal: ${err?.message || "format file tidak terbaca"}`);
    }
  };
  const refreshOnline = async () => {
    setBusy(true); setSyncMessage("Memuat Customer dari Supabase...");
    try {
      if (!isSupabaseConfigured) throw new Error("Supabase belum dikonfigurasi");
      const { data, error } = await fetchAllRows("customers", "polisi");
      if (error) throw error;
      setCustomerDb((data || []).map(customerFromDb));
      setSyncMessage(`✅ ${data?.length || 0} Customer dimuat dari Supabase.`);
      alert(`${data?.length || 0} customer dimuat dari Supabase.`);
    } catch (err) { setSyncMessage(`❌ Gagal memuat Customer: ${err?.message || "kesalahan"}`); alert(`Gagal memuat Supabase: ${err?.message || "kesalahan"}`); }
    finally { setBusy(false); }
  };
  const exportJson = () => {
    const blob = new Blob([JSON.stringify(customerDb, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = "master-customer.json"; a.click(); URL.revokeObjectURL(url);
  };
  const saveOnline = async () => saveCustomerOnline(customerDb, "Master customer berhasil disimpan/update ke Supabase.");
  const saveCustomerCell = async (row, index, key, value) => {
    const updated = { ...row, [key]: value };
    setCustomerDb((prev) => prev.map((x,j)=>j===index ? updated : x));
    if (key === "polisi") {
      const oldPolice = originalPoliceRef.current[index];
      const newPolice = String(value || "").trim().toUpperCase();
      if (oldPolice && norm(oldPolice) !== norm(newPolice) && isSupabaseConfigured) {
        const { error } = await supabase.from("customers").delete().eq("polisi", oldPolice);
        if (error) {
          setSyncMessage(`❌ Plat lama gagal diganti: ${error.message}`);
          return;
        }
      }
      updated.polisi = newPolice;
      originalPoliceRef.current[index] = newPolice;
    }
    await saveCustomerOnline([updated], "Customer otomatis tersimpan.", true);
  };
  const deleteOne = async (c, index) => {
    setCustomerDb(customerDb.filter((_,j)=>j!==index));
    if (!isSupabaseConfigured || !c.polisi) return;
    const { error } = await supabase.from("customers").delete().eq("polisi", c.polisi);
    if (error) alert(`Baris hilang dari layar, tetapi gagal dihapus di Supabase: ${error.message}`);
  };
  const deleteAll = async () => {
    if (!confirm("Hapus semua master customer dari semua perangkat?")) return;
    setCustomerDb([]); localStorage.removeItem("customer_db_v5");
    try {
      if (!isSupabaseConfigured) throw new Error("Supabase belum dikonfigurasi");
      const { error } = await supabase.from("customers").delete().neq("polisi", "__never__");
      if (error) throw error;
      alert("Semua master customer sudah dihapus dari aplikasi dan Supabase.");
    } catch (err) { alert(`Customer lokal sudah kosong, tetapi Supabase gagal dihapus: ${err?.message || "kesalahan"}`); }
  };
  return <section style={styles.card}><h1>Master Customer</h1>
    {syncMessage && <div style={{padding:10,marginBottom:10,borderRadius:6,background:syncMessage.startsWith("❌")?"#fee2e2":syncMessage.startsWith("✅")?"#dcfce7":"#dbeafe"}}>{syncMessage}</div>}
    <p><b>Format Excel:</b> POLICE_NO | MODEL | CUSTOMER | ADDRESS | RANGKA | TELEPHONE_CP. Nama kolom dibaca berdasarkan header, jadi plat tidak akan diambil dari belakang nomor rangka.</p>
    <input ref={excelInputRef} type="file" accept=".xlsx,.xls,.csv" onChange={importExcel} style={{display:"none"}}/>
    <button style={styles.green} disabled={busy} onClick={()=>excelInputRef.current?.click()}>{busy ? "Memproses..." : "Upload Excel Customer"}</button>
    <button style={styles.btn} disabled={busy} onClick={refreshOnline}>{busy ? "Memproses..." : "Refresh dari Supabase"}</button>
    <textarea value={bulk} onChange={(e)=>setBulk(e.target.value)} placeholder={'Bisa juga copy-paste dari Excel beserta header:\nPOLICE_NO\tMODEL\tCUSTOMER\tADDRESS\tRANGKA\tTELEPHONE_CP'} style={styles.bulkBox}/>
    <button style={styles.green} disabled={busy} onClick={importBulk}>{busy ? "Memproses..." : "Import Customer dari Paste"}</button>
    <button style={styles.btn} disabled={busy} onClick={saveOnline}>{busy ? "Memproses..." : "Simpan Semua Customer"}</button>
    <button style={styles.red} onClick={deleteAll}>Delete All Customer</button>
    <button style={styles.btn} onClick={exportJson}>Export Backup</button>
    <button style={styles.btn} onClick={()=>setCustomerDb([...customerDb,{polisi:"",kendaraan:"",customer:"",alamat:"",rangka:"",phone:""}])}>+ Add Customer</button>
    <table style={styles.table}><thead><tr><th>Police No</th><th>Model</th><th>Customer</th><th>Alamat</th><th>No Rangka</th><th>No Telp</th><th>Act</th></tr></thead><tbody>{customerDb.map((c,i)=><tr key={c.id || i}>{["polisi","kendaraan","customer","alamat","rangka","phone"].map(k=><td key={k}><input value={c[k]||""} onFocus={()=>{if(k==="polisi") originalPoliceRef.current[i]=c.polisi;}} onChange={e=>setCustomerDb(customerDb.map((x,j)=>j===i?{...x,[k]:e.target.value}:x))} onBlur={e=>saveCustomerCell(c,i,k,e.target.value)} style={styles.cellInput}/></td>)}<td><button style={styles.del} disabled={busy} onClick={()=>deleteOne(c,i)}>Hapus</button></td></tr>)}</tbody></table></section>
}
function PDFView({refx,form,totals}){
  const tanggal = new Date().toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
  const tanggalSingkat = new Date().toLocaleDateString("id-ID");
  const partsChargeable = (form.parts || []).filter((x)=>!x.free);
  const jasaChargeable = (form.jasa || []).filter((x)=>!x.free);
  const subletsChargeable = (form.sublets || []).filter((x)=>!x.free);
  // Diskon jasa hanya berlaku untuk JASA, tidak termasuk SUBLET.
  const totalJasaGabung = totals.totalJasa + totals.totalSublet;
  const totalPartTampil = totals.totalPartsAfterDisc ?? totals.totalParts;
  const totalJasaTampil = totals.totalJasaAfterDisc ?? totals.totalJasa;
  const noEstimasi = form.noEstimasi || `EST-${new Date().toISOString().slice(0,10).replace(/-/g,"")}`;

  return <div ref={refx} style={styles.pdfNew}>
    <style>{`.pdfCellTable th,.pdfCellTable td{border:1px solid #222;padding:4px 6px;vertical-align:middle;line-height:1.2}.pdfCellTable th{font-weight:800;text-align:center;background:#edf3e8;font-size:11.2px}.pdfCellTable td{text-align:center}.pdfCellTable .left{text-align:left}`}</style>
    <div style={styles.pdfHeaderBar}>
      <div>
        <h1 style={styles.pdfBranch}>PT. AGUNG AUTOMALL GIANYAR</h1>
        <p style={styles.pdfInfo}>JL. BYPASS DHARMA GIRI, BURUAN, BLAHBATUH, GIANYAR</p>
        <p style={styles.pdfInfo}>TLP : 0361-948888</p>
      </div>
      <div style={styles.pdfLogo}>
        <img src="/logo-agung-toyota.png" alt="Agung Toyota" style={styles.pdfLogoImg} />
      </div>
    </div>

    <div style={styles.pdfBlueTitle}>Estimasi Biaya Service Kendaraan</div>

    <div style={styles.pdfDataGridTop}>
      <div>
        <PdfInfo label="No. Estimasi" value={noEstimasi}/>
        <PdfInfo label="Nama Customer" value={form.customer}/>
        <PdfInfo label="Telepon" value={form.phone}/>
        <PdfInfo label="No. Polisi" value={form.polisi}/>
        <PdfInfo label="No. Rangka" value={form.rangka}/>
      </div>
      <div>
        <PdfInfo label="Tanggal" value={tanggalSingkat}/>
        <PdfInfo label="Contact Person" value={form.contact}/>
        <PdfInfo label="Model Kendaraan" value={form.kendaraan}/>
        <PdfInfo label="VIN" value={form.tahun}/>
        <PdfInfo label="Alamat" value={form.alamat}/>
      </div>
    </div>

    <table className="pdfCellTable" style={styles.pdfTableNew}>
      <colgroup><col style={{width:"7%"}}/><col style={{width:"20%"}}/><col style={{width:"30%"}}/><col style={{width:"8%"}}/><col style={{width:"17%"}}/><col style={{width:"18%"}}/></colgroup>
      <thead><tr><th>No.</th><th>Part No</th><th>Part Name</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
      <tbody>{partsChargeable.length ? partsChargeable.map((r,i)=><tr key={r.id||i}><td>{i+1}</td><td>{r.partNo}</td><td className="left">{r.partName}</td><td>{r.qty}</td><td>Rp {rupiah(r.price)}</td><td>Rp {rupiah(r.total)}</td></tr>) : <tr><td colSpan="6">-</td></tr>}</tbody>
    </table>

    <table className="pdfCellTable" style={styles.pdfTableNew}>
      <colgroup><col style={{width:"8%"}}/><col style={{width:"40%"}}/><col style={{width:"16%"}}/><col style={{width:"18%"}}/><col style={{width:"18%"}}/></colgroup>
      <thead><tr><th>No.</th><th>Sublet</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
      <tbody>{subletsChargeable.length ? subletsChargeable.map((r,i)=><tr key={r.id||i}><td>{i+1}</td><td className="left">{r.subletName}</td><td>{r.qty}</td><td>Rp {rupiah(r.price)}</td><td>Rp {rupiah(r.total)}</td></tr>) : <tr><td colSpan="5">-</td></tr>}</tbody>
    </table>

    <table className="pdfCellTable" style={styles.pdfTableNew}>
      <colgroup><col style={{width:"8%"}}/><col style={{width:"40%"}}/><col style={{width:"16%"}}/><col style={{width:"18%"}}/><col style={{width:"18%"}}/></colgroup>
      <thead><tr><th>No.</th><th>Jasa Pekerjaan</th><th>Rate</th><th>Price</th><th>Total</th></tr></thead>
      <tbody>{jasaChargeable.length ? jasaChargeable.map((r,i)=><tr key={r.id||i}><td>{i+1}</td><td className="left">{r.jasaName}</td><td>{r.rate}</td><td>Rp {rupiah(r.price)}</td><td>Rp {rupiah(r.total)}</td></tr>) : <tr><td colSpan="5">-</td></tr>}</tbody>
    </table>

    <div style={styles.pdfTotalRow}>
      <div style={styles.pdfTotalLine}><b>Total Part</b><span>:</span><b>Rp {rupiah(totalPartTampil)}</b></div>
      <div style={styles.pdfTotalLine}><b>Total Sublet</b><span>:</span><b>Rp {rupiah(totals.totalSublet)}</b></div>
      <div style={styles.pdfTotalLine}><b>Total Jasa</b><span>:</span><b>Rp {rupiah(totalJasaTampil)}</b></div>
    </div>
    <div style={styles.pdfGrand}>Grand Total&nbsp;&nbsp;:&nbsp;&nbsp; Rp {rupiah(totals.grandTotal)}</div>

    <div style={styles.pdfBlankColumn}><b>Catatan / Keterangan Tambahan:</b><br/>{form.catatan || ""}</div>

    <div style={styles.pdfBottom}>
      <div style={styles.pdfNote}>
        <b>Keterangan:</b><br/>
        Harga diatas sudah termasuk PPN. Item Part, Pekerjaan dan Harga diatas tidak mengikat sewaktu-waktu dapat berubah. Setelah disetujui mohon ditanda tangani lalu di whatsapp message ke No. 085739025257 / 085338175251.<br/><br/>
        Untuk memudahkan pendaftaran saat kedatangan servis, silahkan Booking ke Petugas Estimasi atau whatsapp message ke No. 085739025257 / 085338175251.
      </div>
      <div style={styles.pdfSignBox}>Disiapkan Oleh,<br/><br/><br/><br/><br/><br/><br/><br/><b>{form.staff}</b><br/><small>{form.jabatan || "Service Advisor"}</small></div>
      <div style={styles.pdfSignBox}>Disetujui Oleh,<br/><br/><br/><br/><br/><br/><br/><br/><b>{form.kepalaBengkel}</b><br/><small>(Kepala Bengkel)</small></div>
      <div style={styles.pdfSignBox}>Pelanggan,<br/><br/><br/><br/><br/><br/><br/><br/><b>{form.customer || "-"}</b></div>
    </div>
    <p style={styles.pdfThanks}>Terima kasih atas kepercayaan Anda kepada Agung Toyota Gianyar.</p>
  </div>
}
function PdfInfo({label,value}){return <div style={styles.pdfInfoRow}><b>{label}</b><span>:</span><span>{value || ""}</span></div>}
function PdfTable({rows,cols}){return <table style={styles.pdfTable}><thead><tr><th>No</th>{cols.map(c=><th key={c}>{c}</th>)}</tr></thead><tbody>{rows.length?rows.map((r,i)=><tr key={r.id||i}><td>{i+1}</td>{cols.map(c=><td key={c}>{["price","total"].includes(c)?"Rp "+rupiah(r[c]):r[c]}</td>)}</tr>):<tr><td colSpan={cols.length+1}>-</td></tr>}</tbody></table>}
const styles={syncBar:{display:"flex",justifyContent:"space-between",gap:12,alignItems:"center",padding:"10px 14px",borderRadius:8,marginBottom:12,fontSize:13,flexWrap:"wrap"},app:{display:"flex",minHeight:"100vh",background:"#f0f0f0",fontFamily:"Arial"},sidebar:{width:260,minWidth:260,padding:12,background:"white",borderRight:"1px solid #ccc",transition:"width .2s ease,min-width .2s ease",overflow:"hidden",position:"sticky",top:0,height:"100vh",zIndex:20},sidebarMini:{width:76,minWidth:76,padding:"12px 8px"},sidebarHeader:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8,marginBottom:12},logo:{color:"red",border:"1px solid #408cff",borderRadius:8,fontSize:28,fontWeight:"bold",width:55,padding:8,textAlign:"center",flexShrink:0},logoMini:{fontSize:18,width:42,padding:"8px 4px"},sidebarToggle:{border:"1px solid #bbb",background:"white",borderRadius:7,width:32,height:32,cursor:"pointer",fontSize:18,fontWeight:"bold",flexShrink:0},navButton:{display:"flex",alignItems:"center",width:"100%",padding:11,background:"white",border:"none",borderBottom:"1px solid #eee",borderRadius:6,textAlign:"left",cursor:"pointer",marginBottom:6},sectionTitle:{fontSize:11,fontWeight:"bold",color:"#777",padding:"10px 12px 5px",letterSpacing:1},menuIcon:{display:"inline-flex",alignItems:"center",justifyContent:"center",width:28,minWidth:28,fontSize:17},menu:{display:"flex",alignItems:"center",gap:6,width:"100%",padding:11,background:"white",border:"none",borderRadius:6,textAlign:"left",cursor:"pointer",whiteSpace:"nowrap"},menuOn:{display:"flex",alignItems:"center",gap:6,width:"100%",padding:11,background:"#0b449d",color:"white",border:"none",borderRadius:6,textAlign:"left",cursor:"pointer",whiteSpace:"nowrap"},databaseHeader:{display:"flex",alignItems:"center",gap:6,width:"100%",padding:11,marginTop:8,background:"#eef1f5",border:"1px solid #d7dce3",borderRadius:7,textAlign:"left",cursor:"pointer",fontWeight:"bold",whiteSpace:"nowrap"},databaseHeaderOn:{display:"flex",alignItems:"center",gap:6,width:"100%",padding:11,marginTop:8,background:"#dfeaff",border:"1px solid #9ebcf0",color:"#0b449d",borderRadius:7,textAlign:"left",cursor:"pointer",fontWeight:"bold",whiteSpace:"nowrap"},chevron:{marginLeft:"auto",fontSize:16},databaseItems:{padding:"5px 0 2px 12px",borderLeft:"2px solid #dbe5f5",marginLeft:14},databaseItemsMini:{paddingTop:5},subMenu:{display:"flex",alignItems:"center",gap:6,width:"100%",padding:"10px 8px",background:"white",border:"none",borderRadius:6,textAlign:"left",cursor:"pointer",fontSize:13,whiteSpace:"nowrap"},subMenuOn:{display:"flex",alignItems:"center",gap:6,width:"100%",padding:"10px 8px",background:"#0b449d",color:"white",border:"none",borderRadius:6,textAlign:"left",cursor:"pointer",fontSize:13,whiteSpace:"nowrap"},main:{flex:1,minWidth:0,padding:20,overflowX:"auto"},card:{background:"white",border:"1px solid #aaa",borderRadius:8,padding:18,marginBottom:18},tabs:{display:"grid",gridTemplateColumns:"1fr 1fr",textAlign:"center",background:"#ddd",borderRadius:6,overflow:"hidden",marginBottom:15},grid4:{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16},grid3:{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16},grid2:{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:16},label:{fontSize:13,fontWeight:"bold"},input:{width:"100%",padding:10,border:"1px solid #bbb",borderRadius:5,marginTop:6,boxSizing:"border-box"},noteInput:{width:"100%",minHeight:70,padding:10,border:"1px solid #bbb",borderRadius:5,marginTop:6,boxSizing:"border-box",fontFamily:"Arial",resize:"vertical"},suggestBox:{position:"absolute",left:0,right:0,top:"100%",background:"white",border:"1px solid #999",borderRadius:6,maxHeight:260,overflowY:"auto",zIndex:99999,boxShadow:"0 8px 18px rgba(0,0,0,.18)",textAlign:"left"},suggestItem:{padding:"10px 12px",borderBottom:"1px solid #eee",fontSize:13,cursor:"pointer",background:"white"},cellInput:{width:"100%",padding:8,border:"1px solid #bbb",borderRadius:5,boxSizing:"border-box"},smallInput:{width:70,padding:8,textAlign:"center",border:"1px solid #bbb",borderRadius:5},table:{width:"100%",borderCollapse:"collapse",marginTop:8},btn:{padding:"9px 14px",border:"1px solid #999",borderRadius:5,background:"white",cursor:"pointer",margin:5},green:{padding:"10px 16px",border:"none",borderRadius:5,background:"#16a34a",color:"white",cursor:"pointer",margin:5},greenRight:{float:"right",padding:"12px 20px",border:"none",borderRadius:6,background:"#16a34a",color:"white",fontWeight:"bold"},blue:{padding:"10px 16px",border:"none",borderRadius:5,background:"#0b45c5",color:"white",cursor:"pointer",margin:5},red:{padding:"10px 16px",border:"none",borderRadius:5,background:"#ef4444",color:"white",cursor:"pointer",margin:5},del:{padding:"7px 10px",border:"none",background:"transparent",color:"red",cursor:"pointer"},discount:{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:12,alignItems:"end",marginTop:20},actions:{display:"flex",justifyContent:"flex-end",gap:8,marginTop:15},pdf:{width:900,background:"white",padding:40,margin:"30px auto",textAlign:"center"},pdfGrid:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:30,textAlign:"left"},pdfTable:{width:"100%",borderCollapse:"collapse",margin:"10px 0 25px"},sign:{display:"flex",justifyContent:"space-between",marginTop:60},flatRateBox:{display:"grid",gridTemplateColumns:"100px 80px 1fr 80px 140px",gap:10,alignItems:"center",background:"#fffbe6",border:"1px solid #d6c67a",borderRadius:7,padding:10,marginBottom:12},select:{width:"100%",padding:9,border:"1px solid #bbb",borderRadius:5,background:"white"},flatRateInput:{padding:9,border:"1px solid #bbb",borderRadius:5,background:"#eee",textAlign:"right",fontWeight:"bold"},totalBox:{gridColumn:"span 1",textAlign:"right",lineHeight:1.2},bulkBox:{width:"100%",minHeight:110,padding:10,border:"1px solid #aaa",borderRadius:6,boxSizing:"border-box",fontFamily:"Consolas, monospace",marginBottom:10},
pdfNew:{width:820,background:"white",padding:"20px 26px",margin:"30px auto",fontFamily:"Arial",color:"#111",fontSize:10},
pdfHeader:{display:"flex",justifyContent:"space-between",alignItems:"flex-start"},pdfHeaderBar:{display:"flex",justifyContent:"space-between",alignItems:"flex-start",padding:"4px 0 12px",textAlign:"left"},
pdfBranch:{fontSize:22,margin:"0 0 5px",fontWeight:"900",letterSpacing:.02,textAlign:"left",whiteSpace:"nowrap"},
pdfInfo:{margin:"4px 0",fontSize:14,fontWeight:"800",textAlign:"left",whiteSpace:"nowrap"},
pdfLogo:{marginTop:3,display:"flex",alignItems:"flex-start",justifyContent:"flex-end",minWidth:225},pdfLogoImg:{height:58,width:"auto",objectFit:"contain",display:"block"},
pdfLogoHorn:{position:"absolute",left:72,top:-4,width:42,height:16,background:"linear-gradient(135deg,#8a692c 0%,#b8944d 55%,#d0b065 100%)",clipPath:"polygon(0 52%, 100% 0, 78% 32%, 5% 88%)",transform:"rotate(-8deg)",transformOrigin:"left center",display:"block"},
pdfDoubleLine:{borderTop:"4px double #111",margin:"18px 0 26px"},
pdfTitle:{textAlign:"center",fontSize:28,margin:"0 0 26px",fontWeight:"800"},pdfBlueTitle:{background:"#14284a",color:"white",textAlign:"center",fontWeight:"800",fontSize:17,padding:"12px",margin:"10px 0 14px"},
pdfDataGrid:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:35,marginBottom:18},pdfDataGridTop:{display:"grid",gridTemplateColumns:"1fr 1fr",columnGap:30,rowGap:0,marginBottom:10,fontSize:12,fontWeight:"800",background:"#f7fbf3",padding:"5px 6px",border:"1px solid #d8e7cf"},
pdfInfoRow:{display:"grid",gridTemplateColumns:"115px 8px 1fr",gap:3,margin:"3px 0",alignItems:"start",textAlign:"left",lineHeight:1.1},
pdfSectionTitle:{textAlign:"center",fontSize:14,margin:"20px 0 8px",fontWeight:"800"},
pdfTableNew:{width:"100%",borderCollapse:"collapse",margin:"7px 0 9px",fontSize:10.2,tableLayout:"fixed"},
pdfTotalRow:{display:"grid",gridTemplateColumns:"1fr",gap:4,borderTop:"2px solid #111",paddingTop:10,marginTop:12,fontSize:12.5,marginLeft:"auto",width:260,textAlign:"right"},
pdfTotalLine:{display:"grid",gridTemplateColumns:"1fr 10px 110px",gap:4,alignItems:"center"},
pdfGrand:{textAlign:"right",fontWeight:"900",fontSize:18,marginTop:10},
pdfDate:{textAlign:"right",fontSize:11,margin:"12px 0"},
pdfBlankColumn:{border:"1px solid #333",minHeight:32,marginTop:12,marginBottom:6,padding:8,textAlign:"left",fontSize:10,lineHeight:1.25,whiteSpace:"pre-wrap"},
pdfBottom:{display:"grid",gridTemplateColumns:"1.55fr 1fr 1fr 1fr",gap:6,marginTop:12},
pdfNote:{border:"1px solid #333",padding:9,textAlign:"left",fontSize:10,lineHeight:1.25,minHeight:86},
pdfSignBox:{border:"1px solid #333",padding:9,textAlign:"center",fontSize:11,minHeight:86},
pdfThanks:{textAlign:"center",fontStyle:"italic",fontWeight:"700",marginTop:24}};
